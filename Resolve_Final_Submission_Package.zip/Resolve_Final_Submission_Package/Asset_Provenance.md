# Production tools and asset provenance

Checked 11 November 2026. No paid generation or speech API was used.

| Asset/tool | Source | Terms / use in this film |
|---|---|---|
| Video Shotcraft | https://github.com/SunCl8/video-shotcraft-skill, revision `d4915443232e89527fdc9d7e79f132ba411fc440` | Apache-2.0 code; copied license under `licenses/`; adapted glyph draw and title-demotion timing, not template product UI |
| Remotion 4.0.542 | https://www.remotion.dev/pricing and repository license linked there | Separate Remotion license. This production assumes the owner's individual hackathon project, eligible for the free individual/up-to-three-person license; not a claim that Apache covers Remotion. Updated from the skill template's 4.0.484 after an actual dependency audit |
| Kokoro-ONNX 0.6.1 | https://github.com/thewh1teagle/kokoro-onnx | MIT library, local CPU ONNX inference; no external TTS service |
| Kokoro 1.0 weights/stock voice | https://huggingface.co/hexgrad/Kokoro-82M | Apache-2.0 weights; stock `am_michael`, not the owner's recorded voice or a voice clone |
| ONNX model/voices distribution | Official `thewh1teagle/kokoro-onnx` release `model-files-v1.1` | `kokoro-v1.0.int8.onnx` SHA-256 `ae315a79b623f244700e4afb9246c46a26066782e049ba174bf3ba433970ee9c`; `voices-v1.0.bin` SHA-256 `bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d` |
| House Vibez — Lily J | https://assets.mixkit.co/music/745/745.mp3 | Mixkit Stock Music Free License, checked category at https://mixkit.co/license/; incorporated quietly into the completed video, not offered as a standalone stock asset |
| Fast small sweep transition | https://assets.mixkit.co/active_storage/sfx/166/166-preview.mp3 | Mixkit Sound Effects Free License, source preserved by Shotcraft attribution; very quiet editorial transitions |
| Manrope | Existing `@fontsource-variable/manrope` application dependency | Existing product font; package OFL license applies. Copied into ignored render public directory, no product-font change |
| Segoe UI captions | Installed Windows font | Used by the local renderer, font file not redistributed |
| Application / source / UI | This repository and actual isolated browser recordings | No template product screenshots, generated UI, stock presenter or fabricated provider log |
| Submission voice / local ASR | `af_heart`, `af_bella`, `am_fenrir` from the same licensed Kokoro release; https://github.com/SYSTRAN/faster-whisper | Three actual voice trials; new submission uses stock `af_heart` at native 1.0 speed. Faster-whisper 1.2.1 is MIT and runs its tiny.en converted Whisper model locally for automated intelligibility checks; it is not a paid speech API or human-listening certification. |

Unused/untraceable Shotcraft audio is not used. In particular, the older
`bgm-tech-house`, `keyboard` and `pop` assets lack sufficient original URL
provenance in that skill; this film chooses documented assets instead. The
no-music edition comes from the same picture/caption/SFX timeline with the music
input disabled, rather than removing speech or filtering a finished soundtrack.

The first-person script represents the project's implementation and reasoning.
It does not claim a human recorded this synthetic voice, that development was
unaided, or that a local application was deployed. Stock voice attribution and
production assistance remain documented here even though there is no intrusive
watermark over the product demo.

## CHG-062 two-stage edition addition

The new master continues stock Kokoro `af_heart` (the three-voice comparison is recorded in CHG-061); it does not use the original film's `am_michael`. Gentle dry button-click foley uses the skill's `switch-click-quick.mp3`: **Quick switch click**, https://assets.mixkit.co/active_storage/sfx/2582/2582-preview.mp3, Mixkit Sound Effects Free License, attribution provenance in the installed skill's `assets/audio/ATTRIBUTION.md`. The initial0.14s click is mixed quietly at actual approval/submit events, not presented as provider audio or a fabricated success notification.

## CHG-064 final narration

New complete paragraphs use stock af_heart with the official full-precision Kokoro1.0 ONNX release (local CPU inference). SHA-256: `beb0d1848dee9a49da392cc3df26958d46cfa35d321edf434f52949153f0df3a`. Official source: https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1 . No cloned voice or external speech API. The documented music repeats through a three-second crossfade and is ducked under speech.
