# SDK INTEGRATION AND IMPLEMENTATION GUIDE

This guide describes the checked-out implementation, not generic vendor examples. Versions come from lock/package files. Installation initializes code; only observed requests to the real service establish integration verification. Reasons below describe the implementation's fit unless an earlier engineering decision explicitly records original selection.

## SDKs versus HTTP integrations

Resolve's Node SDK is first-party. Groq is an official vendor SDK. PayPal, Shopify, EasyPost, Zendesk, Resend and OpenRouter use direct official HTTP APIs through HTTPX/custom adapters; there is no installed PayPal/Shopify/EasyPost/Resend/OpenRouter vendor SDK to claim. PyJWT, Fernet and PostgreSQL clients support security/storage. React/Next.js/FastAPI/Pydantic are application frameworks or validation libraries, not evidence that an external service has been contacted.

## Environment and secret boundary

Ordinary backend variables are loaded by app/settings.py from process environment or backend/.env. AI settings deliberately read process environment only; a private .env.ai.ps1 file is not activated until explicitly sourced. Frontend server variables belong in frontend/.env.local or the host's secret store. Store/SDK variables belong in the integrating server. None belong in NEXT_PUBLIC_* or the browser. Never copy real credential values into these snippets, Git, reports or recordings. See the integration report for missing names and authorization/resource blockers.

## Resolve Evidence SDK

| Item | This project's implementation |
|---|---|
| 1. SDK name | @resolve-paypal/sdk |
| 2. Provider | This repository (first-party; not a PayPal SDK) |
| 3. Version | 0.7.0 |
| 4. Selection / implementation fit | Typed server-only access, generated contract, retry identity and restricted app-source support grants fit the existing app integration; there is no runtime dependency. |
| 5. Installation | npm --prefix sdk/typescript ci; npm --prefix sdk/typescript run build; npm --prefix sdk/typescript pack; install the local tarball in the integrating Node server. The package is not claimed to be published on npm. |
| 6. Initialization file | sdk/typescript/src/index.ts; examples/checkout-store/src/server.mjs |
| 7. Authentication | Opaque Resolve bearer key, independently of PayPal OAuth. Browser cookies alone are not SDK credentials. |
| 8. Required credentials | RESOLVE_API_URL, RESOLVE_API_KEY; source-bound support grant for support actions |
| 9. Configuration | RESOLVE_APP_SOURCE; timeoutMs; retryAttempts; HTTPS or trusted loopback URL |
| 10. Methods used | createResolve, syncOrder, openIssue, getOrderResolution, createSupportLink, lookupIssue, pullEvents, getRefundJourney, getReturnEligibility, getSupportContext, requestOrderReturn, downloadReturnLabel; full exported method index below |
| 11. Request / response handling | Node fetch, bounded timeouts, typed generated JSON, fixed relative paths and no redirects |
| 12. Error handling | ResolveApiError/ResolveTransportError; no raw error body is surfaced. Retries retain write identity only for supported safe operations; link rotation is not blindly retried. |
| 13. Backend integration | Store server creates one ResolveClient. /api/orders actions call it after checking receipt-session ownership. |
| 14. Frontend integration | No merchant key goes into browser code. public/app.js calls only its own store routes; portal links are explicit user actions. |
| 15. Database interaction | FastAPI owns Resolve persistence; store_orders holds the app receipt and Resolve case reference. SDK does not secretly read a merchant DB. |
| 16. Complete execution flow | Buyer action -> store route/session check -> Resolve SDK -> FastAPI scoped grant -> transaction/evidence adapter -> JSON -> store route -> buyer UI |

## HTTPX and real provider adapters

| Item | This project's implementation |
|---|---|
| 1. SDK name | httpx (generic HTTP transport, not a provider SDK) |
| 2. Provider | Encode / HTTPX community; providers supply official HTTP APIs |
| 3. Version | 0.28.1 |
| 4. Selection / implementation fit | Existing adapters validate explicit provider responses, fixed hosts, seller identity and bounds; no additional vendor SDK is installed for PayPal, Shopify, EasyPost, Zendesk, Resend or OpenRouter. |
| 5. Installation | cd backend; uv sync --locked |
| 6. Initialization file | app/paypal.py; app/resolution_providers.py; app/helpdesk.py; app/platform_imports.py; app/customer_email.py; app/inference.py |
| 7. Authentication | PayPal client_credentials + Bearer; Shopify X-Shopify-Access-Token; EasyPost HTTP Basic API key; Zendesk/Resend/OpenRouter Bearer |
| 8. Required credentials | Provider-specific variables in the adapter matrix below; optional encrypted per-workspace connection |
| 9. Configuration | Ordinary settings: process environment/backend .env. AI: process environment only. Provider reads/writes have separate enablement. |
| 10. Methods used | httpx.Client.request, get, post, stream; PayPalSandboxClient.read_capture/read_refund/read_refund_history; ProofProviders.read; provider_json; deliver |
| 11. Request / response handling | No redirects; normal provider clients set trust_env=False; responses are bounded and structurally validated, with monetary strings checked using Decimal/Pydantic. |
| 12. Error handling | PayPal timeout 504, transport/invalid response 502, rejected app credentials/unavailable/rate limit 503; business conflicts 409. Provider body/credentials are not displayed. |
| 13. Backend integration | FastAPI routes call ownership-scoped services; separate workers recover jobs and refresh authorized evidence. |
| 14. Frontend integration | Next.js forwards same-origin requests server-side. Client forms receive sanitized detail/status; no public provider secrets. |
| 15. Database interaction | Only validated observations become source-labelled records in transactions. Manual notes and provider observations remain separate. |
| 16. Complete execution flow | Merchant click -> /api/resolve gateway -> backend authorization -> service -> real HTTPS provider -> validation -> database/audit -> response -> refreshed UI |

## Groq Python SDK

| Item | This project's implementation |
|---|---|
| 1. SDK name | groq |
| 2. Provider | Groq (official Python SDK) |
| 3. Version | 1.7.0 |
| 4. Selection / implementation fit | The implemented extraction path uses the official client and its typed API exceptions. Existing inference jobs also have an HTTPX adapter; that is a separate code path, not evidence that the SDK ran. |
| 5. Installation | cd backend; uv sync --locked |
| 6. Initialization file | backend/app/ai_routes.py:get_ai_client; backend/app/platform_imports.py |
| 7. Authentication | API key passed on the server to groq.Groq |
| 8. Required credentials | RESOLVE_AI_GROQ_KEY |
| 9. Configuration | RESOLVE_EXTRACTION_ENABLED; RESOLVE_AI_DATA_POLICY; RESOLVE_EXTRACTION_MODEL; timeout/daily token limits. Environment only. |
| 10. Methods used | Groq(...), client.chat.completions.create(...), close; see ai_extraction.py |
| 11. Request / response handling | A minimized transcript and strict structured schema are submitted; verbatim merchant quote, source message and amount gates validate proposals. |
| 12. Error handling | APITimeoutError, APIConnectionError and APIStatusError become needs_review. Budget/privacy rejection blocks calls. A model proposal is not saved or paid automatically. |
| 13. Backend integration | POST case ai/extract-promises and explain-next-action use dependency-injected SDK clients; importing Zendesk can use the same optional path. |
| 14. Frontend integration | Promise suggestions appear for merchant review. Choosing a proposal fills the normal form; saving is a separate authenticated action. |
| 15. Database interaction | Usage counters and reviewed promises are stored; extraction itself is advisory. It never authorizes a refund. |
| 16. Complete execution flow | Merchant requests analysis -> privacy/budget gate -> Groq SDK -> real Groq endpoint -> structured/quote validation -> proposal -> merchant-reviewed save. Paid/production-key calls remain blocked without explicit authorization. |

## PostgreSQL Python driver and pool

| Item | This project's implementation |
|---|---|
| 1. SDK name | psycopg[binary] and psycopg-pool |
| 2. Provider | Psycopg project (database driver, not a Neon SDK) |
| 3. Version | 3.3.8 / 3.3.3 |
| 4. Selection / implementation fit | The existing SQLite repository abstraction is retained; PostgreSQL adds durable hosted storage and bounded reusable connections without a second ORM. |
| 5. Installation | cd backend; uv sync --locked |
| 6. Initialization file | backend/app/postgres.py:PostgresStore; backend/app/storage.py:configured_store |
| 7. Authentication | Database connection URL / PostgreSQL role credentials |
| 8. Required credentials | RESOLVE_DATABASE_URL (private); provider-supplied TLS options |
| 9. Configuration | Per-process connection pool; schema and transaction isolation managed by PostgresStore |
| 10. Methods used | ConnectionPool.connection, execute, fetchone/fetchall, transactions, sql.Identifier |
| 11. Request / response handling | Parameterized SQL values and quoted identifiers; read-only repeatable-read snapshots and serialized writes preserve authoritative reconciliation state. |
| 12. Error handling | Operational/pool/timeouts become sanitized 503; expected integrity/business conflicts retain domain errors. |
| 13. Backend integration | API, CLI and all workers use the same configured store. Lifespan closes pools. |
| 14. Frontend integration | No database connection string is shipped to browser JavaScript. |
| 15. Database interaction | Checksum-verified immutable migrations, case/order/event/evidence/session transactions, shared balances and idempotency constraints. |
| 16. Complete execution flow | API authorization -> store transaction -> PostgreSQL driver/pool -> SQL constraints/snapshot -> mapped domain response. Disposable DB validation does not verify the configured hosted account. |

## Node PostgreSQL adapter / consumer

| Item | This project's implementation |
|---|---|
| 1. SDK name | pg-compatible pool supplied by the integrating app |
| 2. Provider | node-postgres community; Resolve connector is first-party |
| 3. Version | pg 8.23.1 |
| 4. Selection / implementation fit | Injected read/query interfaces let the merchant own DB authentication and approved views; the SDK does not request arbitrary customer tables. |
| 5. Installation | Install pg in the integrating server when using these optional adapters; build the local SDK as above. |
| 6. Initialization file | sdk/typescript/src/commerce.ts; sdk/typescript/src/events.ts; SDK PostgreSQL examples |
| 7. Authentication | App-owned pool/role connectionString; source-bound Resolve key separately |
| 8. Required credentials | App database URL in the integrating server secret store; Resolve server variables separately |
| 9. Configuration | Approved projection views/queries and stream consumer checkpoint table; caller owns pool configuration |
| 10. Methods used | PostgresCommerce.sync/backfill; PostgresResolutionConsumer.consume; pool.connect/query/release; transactional callback |
| 11. Request / response handling | Selected fields are projected into versioned order snapshots. Stream consumers apply callbacks/checkpoints atomically. |
| 12. Error handling | Invalid source shape/query raises CommerceSourceError. Transactions roll back failed consumers; duplicate/older events do not reapply effects. |
| 13. Backend integration | Merchant app server reads its authorized views then sends snapshots through ResolveClient. Consumer runs in the app process. |
| 14. Frontend integration | No browser DB credentials or direct browser SQL. |
| 15. Database interaction | App views are read-only; the optional app event consumer owns its own checkpoint transaction/table, separate from Resolve migrations. |
| 16. Complete execution flow | App DB view -> PostgresCommerce -> SDK -> Resolve ingestion -> evidence comparison; event feed -> app transaction -> callback + checkpoint commit/rollback |

## Nodemailer SMTP transport

| Item | This project's implementation |
|---|---|
| 1. SDK name | nodemailer |
| 2. Provider | Nodemailer project (SMTP client, not Gmail/Resend SDK) |
| 3. Version | 10.3.1 |
| 4. Selection / implementation fit | The existing follow-up worker can use standard SMTP through a small Node subprocess while keeping secrets out of process arguments and output. |
| 5. Installation | npm ci --prefix backend/mailer; install Node on the follow-up worker; retain Python backend dependencies |
| 6. Initialization file | backend/mailer/send.mjs; backend/app/customer_smtp.py |
| 7. Authentication | SMTP auth user/password over implicit TLS or required STARTTLS |
| 8. Required credentials | RESOLVE_SMTP_HOST/PORT/SECURE/USER/PASSWORD/FROM; customer signing key/origin/merchant binding |
| 9. Configuration | RESOLVE_CUSTOMER_EMAIL_ENABLED=true; RESOLVE_CUSTOMER_EMAIL_TRANSPORT=smtp, only after authorized delivery testing |
| 10. Methods used | nodemailer.createTransport; transport.sendMail; transport.close |
| 11. Request / response handling | Python sends a JSON payload on stdin; Node returns only accepted/retry/failed. TLS minimum 1.2; file/URL access disabled; bounded connection/greeting/socket timeouts. |
| 12. Error handling | Explicit transient SMTP rejections may retry; ambiguous transfer failure is not auto-retried as if nothing was sent. stderr is suppressed to avoid credential leakage. |
| 13. Backend integration | followup_worker -> customer_email.deliver -> send_smtp -> Node transport -> SMTP |
| 14. Frontend integration | UI queues or requests mail; a queued notice is not a delivery claim. |
| 15. Database interaction | Durable outbox keeps intended notice identity/status. SMTP acceptance is not inbox receipt. |
| 16. Complete execution flow | Authenticated action -> outbox transaction -> separate worker -> Nodemailer -> SMTP acceptance/failure -> outbox state -> UI status. No real message is sent without authorization. |

## PyJWT / Google token validation

| Item | This project's implementation |
|---|---|
| 1. SDK name | PyJWT with crypto |
| 2. Provider | PyJWT community; Google supplies OIDC/JWKS (no Google client SDK installed) |
| 3. Version | 2.15.1 |
| 4. Selection / implementation fit | The implementation uses OIDC authorization code/PKCE and verifies signatures/claims locally; adding a second browser identity SDK was unnecessary for this architecture. |
| 5. Installation | cd backend; uv sync --locked |
| 6. Initialization file | backend/app/customer_google.py:_verify; frontend/app/api/customer-account/[...path]/route.ts |
| 7. Authentication | OAuth client ID/secret, one-use state, PKCE verifier; signed RS256 ID token |
| 8. Required credentials | RESOLVE_GOOGLE_CLIENT_ID / SECRET and exact customer HTTPS origin; Google-enabled flag |
| 9. Configuration | Registered /api/customer-account/google/callback; server-only secret, exact issuer/audience and authoritative email checks |
| 10. Methods used | jwt.get_unverified_header (key selection only), PyJWK.from_dict, jwt.decode |
| 11. Request / response handling | JWKS key and token issuer/audience/expiry are verified; unverified header claims are never trusted as identity. |
| 12. Error handling | Bad state/code/signature/claims/address authority produce sanitized failure; missing config is disabled/unavailable, not a fabricated login. |
| 13. Backend integration | CustomerAccounts binds verified email to invited cases and isolated customer sessions. |
| 14. Frontend integration | Buyer chooses Google, approves on Google, returns to server callback; no Google secret appears in the browser. |
| 15. Database interaction | One-time flow records, customer sessions and mailbox-bound links are durable and expiring. |
| 16. Complete execution flow | Buyer -> state/PKCE -> official Google consent/token/JWKS -> PyJWT verify -> invited mailbox lookup -> customer cookie -> own cases |

## Fernet connection encryption

| Item | This project's implementation |
|---|---|
| 1. SDK name | cryptography.fernet.Fernet |
| 2. Provider | Python Cryptographic Authority |
| 3. Version | 50.0.2 |
| 4. Selection / implementation fit | A stable symmetric key protects per-workspace provider secrets; it fits the existing server-side connection registry and reversible credential use. |
| 5. Installation | cd backend; uv sync --locked |
| 6. Initialization file | backend/app/platform_connections.py:Connections.cipher/decrypt/save |
| 7. Authentication | Not provider authentication; local authenticated encryption protects stored credentials |
| 8. Required credentials | RESOLVE_PLATFORM_ENCRYPTION_KEY (shared stable Fernet key) |
| 9. Configuration | Same key on API/workers and private backups; do not regenerate for existing encrypted rows |
| 10. Methods used | Fernet(...), encrypt, decrypt; InvalidToken handling |
| 11. Request / response handling | Only redacted connection configuration/status returns to clients. Decrypted secrets stay in server memory for a scoped provider request. |
| 12. Error handling | Missing/invalid key or InvalidToken returns sanitized 503. Wrong keys do not silently reset credentials. |
| 13. Backend integration | Connections enforces owner role, expected revision and merchant/provider ownership. |
| 14. Frontend integration | Owners submit secret fields over the gateway; listing never returns plaintext secrets. |
| 15. Database interaction | platform_connections stores credentials_ciphertext, safe config and revision/check status; connection changes invalidate stale financial assumptions. |
| 16. Complete execution flow | Owner form -> backend owner/revision gate -> Fernet encrypt -> DB; provider check -> decrypt -> real API -> safe status |

## Actual source excerpts

These are extracted from the current source files. Class methods are shown as methods, not standalone executable programs. Read the named files for surrounding imports/types. No configured values or customer data are included.

### Resolve client initialization

Source: `sdk/typescript/src/index.ts`

```typescript
  constructor(options: ResolveClientOptions) {
    if (typeof window !== "undefined" && typeof window.document !== "undefined") {
      throw new TypeError("Use ResolveClient on the server; never put a merchant key in browser code.");
    }
    if (typeof options.apiKey !== "string" || !/^rslv_[A-Za-z0-9_-]{43}$/.test(options.apiKey)) {
      throw new TypeError("Set a valid Resolve merchant access key.");
    }
    this.#base = apiBase(options.baseUrl);
    this.#apiKey = options.apiKey;
    this.#source = options.source ?? "my-app";
    if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/.test(this.#source)) {
      throw new TypeError("Set a valid RESOLVE_APP_SOURCE, such as my-store.");
    }
    this.#retryAttempts = options.retryAttempts ?? 3;
    if (!Number.isInteger(this.#retryAttempts) || this.#retryAttempts < 1 || this.#retryAttempts > 4) throw new TypeError("Use retryAttempts between 1 and 4.");
    this.#timeoutMs = options.timeoutMs ?? 10_000;
    if (!Number.isInteger(this.#timeoutMs) || this.#timeoutMs < 1 || this.#timeoutMs > 120_000) {
      throw new TypeError("Set timeoutMs to an integer between 1 and 120,000.");
    }
  }
```

### Order synchronization

Source: `sdk/typescript/src/index.ts`

```typescript
  syncOrder(order: SimpleOrder, options?: RequestOptions): Promise<CommerceOrderReceipt> {
    const { id, version, status, ...fields } = order;
    return this.registerCommerceOrder({
      ...fields, source: this.#source, order_reference: id, revision: version ?? 1,
      ...(status !== undefined ? { order_status: status } : {}),
    }, options);
  }
```

### Order support call

Source: `sdk/typescript/src/index.ts`

```typescript
  openIssue(input: OpenIssueInput, options?: RequestOptions): Promise<IssueReceipt> {
    const { orderId, requestId, reason, message, requestedResolution } = input;
    return this.#request("POST", "/aftercare/issues", options, {
      source: this.#source, order_reference: orderId, request_id: requestId, reason, message,
      ...(requestedResolution !== undefined ? { requested_resolution: requestedResolution } : {}),
    });
  }
```

### PayPal transport initialization

Source: `backend/app/paypal.py`

```python
    def __init__(self, settings: Settings, http_client: httpx.Client | None = None):
        self.settings = settings
        # Test injection configures an actual local HTTP proxy, never a runtime base URL.
        self.http = (
            http_client
            if http_client is not None
            else httpx.Client(
                timeout=httpx.Timeout(10.0, connect=5.0),
                follow_redirects=False,
                trust_env=False,
            )
        )
```

### PayPal authentication

Source: `backend/app/paypal.py`

```python
    def _access_token(self, settings: Settings) -> str:
        data = self._json_request(
            "POST",
            "/v1/oauth2/token",
            token_request=True,
            auth=httpx.BasicAuth(
                settings.paypal_sandbox_client_id.get_secret_value(),
                settings.paypal_sandbox_client_secret.get_secret_value(),
            ),
            data={"grant_type": "client_credentials"},
            headers={"Accept": "application/json"},
        )
        try:
            token = _OAuthToken.model_validate(data)
        except ValidationError:
            raise StoreError(
                502, "PayPal Sandbox returned an invalid token response"
            ) from None
        return token.access_token.get_secret_value()
```

### Provider response/error mapping

Source: `backend/app/paypal.py`

```python
    def _json_request(
        self,
        method,
        path,
        *,
        token_request=False,
        not_found_detail="PayPal Sandbox capture was not found",
        **kwargs,
    ):
        try:
            response = self.http.request(
                method, SANDBOX_BASE_URL + path, follow_redirects=False, **kwargs
            )
        except httpx.TimeoutException:
            raise StoreError(504, "PayPal Sandbox request timed out") from None
        except httpx.HTTPError:
            raise StoreError(502, "PayPal Sandbox connection failed") from None
        if response.status_code == 404 and not token_request:
            raise StoreError(404, not_found_detail)
        if response.status_code in (401, 403):
            if token_request:
                raise StoreError(503, "PayPal Sandbox credentials were rejected")
            raise StoreError(502, "PayPal Sandbox could not authorize the capture read")
        if response.status_code == 429 or response.status_code >= 500:
            raise StoreError(503, "PayPal Sandbox is temporarily unavailable")
        if response.status_code != 200:
            raise StoreError(502, "PayPal Sandbox returned an unexpected response")
        try:
            return response.json()
        except ValueError:
            raise StoreError(
                502, "PayPal Sandbox returned an invalid response"
            ) from None
```

### Groq SDK initialization

Source: `backend/app/ai_routes.py`

```python
def get_ai_client(settings: Annotated[ExtractionSettings, Depends(get_ai_settings)]):
    if not settings.enabled or settings.groq_key is None:
        yield None
        return
    client = groq.Groq(
        api_key=settings.groq_key.get_secret_value(),
        timeout=settings.timeout_seconds,
        max_retries=1,
    )
    try:
        yield client
    finally:
        client.close()
```

### Fernet initialization

Source: `backend/app/platform_connections.py`

```python
    def cipher(self):
        try:
            return Fernet(
                self.settings.platform_encryption_key.get_secret_value().encode()
            )
        except (AttributeError, ValueError):
            raise StoreError(
                503,
                "Set RESOLVE_PLATFORM_ENCRYPTION_KEY to a stable Fernet key before connecting accounts",
            ) from None
```

### Google verification

Source: `backend/app/customer_google.py`

```python
    def _verify(config, http, code, verifier):
        try:
            client_id = config.client_id.get_secret_value()
            result = http.post(
                TOKEN,
                data={
                    "client_id": client_id,
                    "client_secret": config.client_secret.get_secret_value(),
                    "redirect_uri": config.callback,
                    "grant_type": "authorization_code",
                    "code": code,
                    "code_verifier": verifier,
                },
            )
            if result.status_code == 400:
                raise StoreError(400, "Google did not accept this sign-in attempt")
            result.raise_for_status()
            grant = result.json()
            token = grant.get("id_token") if isinstance(grant, dict) else None
            if not isinstance(token, str) or not 0 < len(token) <= 8192:
                raise ValueError
            header = jwt.get_unverified_header(token)
            kid = header.get("kid")
            if (
                header.get("alg") != "RS256"
                or not isinstance(kid, str)
                or not 0 < len(kid) <= 128
            ):
                raise ValueError
            response = http.get(KEYS)
            response.raise_for_status()
            jwks = response.json()
            keys = jwks.get("keys") if isinstance(jwks, dict) else None
            if not isinstance(keys, list):
                raise ValueError
            matches = [
                key
                for key in keys
                if isinstance(key, dict)
                and key.get("kid") == kid
                and key.get("kty") == "RSA"
            ]
            if len(matches) != 1:
                raise ValueError
            claims = jwt.decode(
                token,
                jwt.PyJWK.from_dict(matches[0], algorithm="RS256").key,
                algorithms=["RS256"],
                audience=client_id,
                issuer=("https://accounts.google.com", "accounts.google.com"),
                options={
                    "strict_aud": True,
                    "require": [
                        "sub",
                        "iss",
                        "aud",
                        "exp",
                        "iat",
                        "nonce",
                        "email",
                        "email_verified",
                    ],
                },
            )
            if not claims["sub"] or claims.get("azp", client_id) != client_id:
                raise ValueError
            return claims
        except (httpx.HTTPError, jwt.PyJWTError, TypeError, ValueError):
            raise StoreError(503, "Google sign-in could not be verified") from None
```

### SMTP transport

Source: `backend/mailer/send.mjs`

```javascript
import { readFileSync } from "node:fs";
import nodemailer from "nodemailer";

let status = "failed";
let transport;
try {
  const { host, port, secure, user, password, message } = JSON.parse(readFileSync(0, "utf8"));
  transport = nodemailer.createTransport({
    host,
    port,
    secure,
    requireTLS: !secure,
    auth: { user, pass: password },
    tls: { minVersion: "TLSv1.2" },
    connectionTimeout: 8_000,
    greetingTimeout: 8_000,
    socketTimeout: 10_000,
    disableFileAccess: true,
    disableUrlAccess: true,
  });
  const result = await transport.sendMail(message);
  if (result.accepted.length === 1 && !result.rejected.length) status = "accepted";
} catch (error) {
  // An explicit transient SMTP rejection is safe to retry; an interrupted
  // transfer may already have been accepted and is never retried automatically.
  if (Number.isInteger(error?.responseCode) && error.responseCode >= 400 &&
      error.responseCode < 500) status = "retry";
} finally {
  transport?.close();
}
process.stdout.write(JSON.stringify({ status }));

```

## Provider adapter configuration and real request flow

| Integration | Actual implementation / protocol | Configuration and effect boundary |
|---|---|---|
| PayPal Sandbox payments | app/paypal.py, executions.py, paypal_history.py; OAuth, capture/order/refund GETs, separately approved capture-refund POST, signed webhook verification | RESOLVE_PAYPAL_SANDBOX_CLIENT_ID/SECRET/MERCHANT_ID; RESOLVE_PAYPAL_RESOLVE_MERCHANT_ID; read/write/partial flags and webhook ID. Fixed Sandbox host; user confirmation required for the audit order/capture/refund. |
| PayPal merchant identity | app/merchant_auth.py:PayPalIdentity; authorization code and subject read | RESOLVE_PAYPAL_LOGIN_CLIENT_ID/SECRET/ENVIRONMENT and exact merchant origin; linked-account consent is separate from payment authorization. |
| Shopify | resolution_providers.py:_shopify_read; Admin GraphQL with fixed shop hostname | RESOLVE_SHOPIFY_SHOP_DOMAIN / ADMIN_TOKEN / RESOLUTION_CONNECTOR_MERCHANT_ID, or encrypted owning connection; read evidence only. No order mutation or fulfillment creation is implemented. |
| EasyPost | resolution_providers.py:tracking; GET existing tracker with Basic auth | RESOLVE_EASYPOST_API_KEY and connector binding or owning connection. No shipment/label purchase/tracking-ID creation is implemented. |
| Zendesk | helpdesk.py, platform_imports.py and operations_worker; ticket/comment reads and signed webhook jobs | RESOLVE_ZENDESK_SUBDOMAIN / OAUTH_TOKEN / HELPDESK_MERCHANT_ID or encrypted connection/webhook_secret. Private comments remain private. |
| Resend | customer_email.py:deliver; POST /emails with stable idempotency identity | RESOLVE_RESEND_API_KEY / FROM plus customer signing key/origin/merchant binding. Queued is not sent; API acceptance is not inbox delivery. |
| OpenRouter | inference.py:OpenRouterProvider; structured chat via HTTPX | RESOLVE_AI_OPENROUTER_KEY / ENABLED / DATA_POLICY and routing settings. No production-key/model call is authorized by the read-only audit. |
| SMTP | customer_smtp.py -> send.mjs -> real SMTP | Credentials/configuration in SDK table; a verified sender/recipient and explicit delivery authorization are still required. |

## Full first-party SDK method index

- `syncOrder`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `openIssue`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getOrderResolution`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `createSupportLink`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getRefundJourney`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getSupportContext`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `lookupIssue`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `acknowledgeRefundReceived`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `pullEvents`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getReturnEligibility`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getOrderReturns`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `requestOrderReturn`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getReturnGuide`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `downloadReturnLabel`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `saveReturnPolicy`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `recordDispute`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `recordRefundTrace`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `recordDisputeEvidence`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `saveReturnGuide`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `uploadReturnLabel`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `recordReturnInspection`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `registerCommerceOrder`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `syncCommerceOrder`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getCommerceOrder`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getCommerceContact`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `refreshCommerceOrder`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `connectPostgres`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getMerchant`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `createCase`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `upsertCase`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `linkRecord`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `addEvidence`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `refreshEvidence`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getInvestigations`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getOperationsDashboard`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getMissedPromises`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `scanMissedPromises`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `importZendeskTicket`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `confirmSupportImport`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `publishResolutionOffer`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getReturnWorkflow`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `requestReturn`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `updateReturn`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `prepareDisputePackage`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `reviewDisputePackage`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `reviewInvestigation`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getCase`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `listCases`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getCaseTimeline`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getTimeline`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getEvidenceBundle`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `issueCustomerLink`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `createBuyerLink`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `getCustomerLink`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.
- `revokeCustomerLink`: implementation in `sdk/typescript/src/index.ts`; generated request/response types come from `postman/contracts/resolve.openapi.json`.

## Practical implemented flows

### Store order, payment and aftercare

1. public/app.js submits cart items and a request identity to the store server. The server quotes catalog prices and binds the receipt to the HttpOnly session.
2. SandboxPayPal.create sends an actual PayPal order request and validates the approval link. Buyer consent happens on PayPal; it is not simulated by the application.
3. The callback receipt uses SandboxPayPal.capture, which first reads the order and reuses capture identity. It validates amount, currency, seller, reference and capture count before saving store_orders.
4. server.mjs sync calls ResolveClient to register/sync the actual order snapshot. Resolve stores the revision and reads configured provider evidence only through authorized services.
5. The buyer submits a support request. The store verifies receipt ownership, then calls openIssue. Duplicate request IDs retain the same issue receipt. getOrderResolution/getSupportContext/getRefundJourney read safe status; createSupportLink grants the explicit private portal.
6. Failed/missing configuration stays a failure or unavailable state. There is no product DemoStore or fabricated fallback order/refund state. Controlled doubles are allowed only in isolated tests and never establish real-service VERIFIED status.

### Merchant evidence to refund

Merchant workspace -> same-origin Next gateway -> merchant/role gate -> current promise/acceptance/condition checks -> fresh real Sandbox capture/history -> exact state-bound approval -> separate execution -> provider identity/amount check -> durable request/outcome -> independent refund read -> reconciliation and safe buyer update. A provider timeout can mean an unknown outcome; recovery reads the existing request instead of treating it as a new refund.

### Current verification boundary

Consult `docs/testing/production-integration-report.md` for actual results, endpoint/status evidence and missing credentials. Real OAuth/order creation are distinct from completed buyer approval/capture/refund. Local database/SDK success does not verify hosted PostgreSQL, Render deployment, a real mailbox or a carrier account.

## Official references used to check protocol terminology

- [PayPal authentication](https://developer.paypal.com/api/rest/authentication)
- [Groq Python quickstart](https://console.groq.com/docs/quickstart)
- [Google OpenID Connect](https://developers.google.com/identity/openid-connect/openid-connect)
- [Nodemailer SMTP](https://nodemailer.com/smtp)
