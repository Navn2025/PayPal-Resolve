# Resolve submission package

Start with [Technical documentation](output/pdf/Resolve_Technical_Documentation.pdf).
The 14-page guide covers architecture, reconciliation, merchant/buyer workflows,
local installation, configuration, API and SDK use, Postman simulations,
recorded validation and operational limits.

## Quick local start

Use Python 3.12+, uv, npm and Node.js 24. From `backend`, run `uv sync`, copy
`.env.example` to `.env` for a fresh installation and start
`uv run uvicorn app.main:app --reload`. Create a merchant in another backend
terminal with `uv run python -m app.manage create-merchant --name "Review store"`.
Save the printed token privately. From `frontend`, run `npm ci`, copy
`.env.example` to `.env.local`, then run `npm run dev`. Open
http://127.0.0.1:3000 and connect the merchant. Provider accounts are optional
for local startup; Sandbox reads/refund writes and inference default off.

Component instructions are in `backend/README.md`, `frontend/README.md`,
`sdk/typescript/README.md`, `examples/checkout-store/README.md` and
`postman/README.md`. The Postman directory includes contracts, mocks and
simulations. The canonical API contract is
`postman/contracts/resolve.openapi.json`.

## Package scope

This is the current working-tree source, not a committed release. The archive
excludes all Git-ignored paths, `.git`, assistant-tool bundles and older archives.
The broad ignored `docs/` directory is absent, so some older README links point
outside this package. The included PDF and component READMEs supply the review
path. Dependencies and build outputs must be installed or rebuilt.

The new PDF's editable text and renderer are in `submission/`. See the renderer's
module docstring for rebuild instructions. Recorded application test results are
historical evidence, not new tests performed during documentation preparation.
PayPal demonstrations use Sandbox test funds; AI review never authorizes money
movement.
