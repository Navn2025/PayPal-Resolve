Submit Resolve_Final_Submission.mp4 — 2 minutes 50 seconds.

The companion WAVs, SRT, script, timeline, no-music MP4 and review reports are in this directory.
