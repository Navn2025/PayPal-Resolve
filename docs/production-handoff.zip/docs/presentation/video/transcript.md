# Resolve - complete English walkthrough transcript

Actual local application captures and separately labelled previously verified official Sandbox evidence. No new payment, fake UI, production deployment or successful unconfigured integration is claimed.

## 01. Welcome to Resolve

Welcome to Resolve, a payment aftercare application for merchants and buyers. This detailed tour explains the actual pages and the main actions available in each module. Most screens use a local workspace with clearly labelled quality assurance records. The financial evidence chapter shows the previously verified official PayPal Sandbox transaction. Public production deployment remains pending. Use the chapter list to jump to any feature.

## 02. Home and navigation

The home page explains the issue, agreement, and verification workflow. Choose the workspace entry for merchant access, the customer portal for an existing private link, or Docs for public help. Once signed in, the workspace navigation connects Cases, Orders, Operations, and Settings. Documentation remains available without signing in. Old demo addresses redirect to real access; they do not create sample transactions.

## 03. Create a merchant workspace

To register, open the account page and select Create workspace. Enter the business name, your name, an email address, and a password between twelve and two hundred and fifty-six characters. Submit once and wait for the result. The new account becomes the workspace owner. Existing key-based merchants should claim their existing workspace instead of accidentally creating a separate business with separate records.

## 04. Sign-in methods and access recovery

Staff sign in using their email and password on the account page. Existing merchants can also use a full Resolve access key on the merchant login page. PayPal identity sign-in is optional and requires a configured, linked account; identity login does not authorize refunds. Incorrect credentials produce an error. There is no public password-reset workflow, so access recovery currently requires the workspace owner or administrator.

## 05. Sessions and safe account use

After authentication, the browser receives a protected session cookie rather than a copy of the merchant key. Merchant sessions expire after eight hours, and access changes can revoke them earlier. Settings identifies the active workspace and sign-in state. Use Sign out when finished, especially on a shared computer. Customer sessions and merchant sessions have separate permissions; one does not grant access to the other.

## 06. Find and prioritize cases

Cases is the merchant's work queue. Select a case to see its detail, or search for a title or order reference. Use workflow filters to find unread messages, customer-dependent work, approvals, pending provider outcomes, or completed remedies. The At risk filter highlights relevant refund promises. Load more cases when results span several pages. Refresh to retrieve current stored information rather than assuming an older list is complete.

## 07. Review queue and source labels

The review queue collects provider and refund exceptions that need attention. Open the related case and inspect the reason before acting. Some blocking items require new provider evidence rather than a manual dismissal. Throughout the interface, pay attention to source labels. Merchant recorded means a person or connected application entered the information. Provider confirmed means a supported external service supplied evidence. A missing check remains an evidence gap.

## 08. Create a case and link payment

Select New case and enter the issue title and optional order reference. A case can start without a payment, link an existing owned payment case, or record payment details for later verification. When recording a PayPal payment, use the actual order identifier, capture identifier, and captured amount. These identifiers are different. A successful save creates a persistent case; a manually recorded amount is not yet independent payment proof.

## 09. Assignment, deadlines, and lifecycle

Manage case provides assignment, due-date, and waiting-state controls. Enter a responsible person or team, set a deadline where appropriate, and indicate when the buyer needs to respond. The inbox then reflects the next actor and overdue work. Supported close and reopen actions retain their reasons and history. Closing a support case does not prove that a refund completed. General permanent case deletion is not implemented.

## 10. Record the agreed remedy

Choose Add promise to record what the merchant actually agreed to do. Select a remedy, enter the customer-facing promise, and identify its source evidence. Complete the fields for that remedy, such as an amount, return reference, or milestone. Resolve can record refunds, returns, replacements, cancellations, subscription changes, credit or exchange, billing correction, and dispute handoff. Recording one of these promises does not automatically perform the corresponding external action.

## 11. Revisions and dependencies

A promise can include a due date and prerequisites, such as receiving a return before a refund becomes eligible. Editing the terms creates a new version. Earlier evidence, accepted offers, and approvals may no longer apply to that version. Review the revised state before proceeding. A buyer request remains separate from a merchant agreement, and a changed promise must not silently reuse an older decision.

## 12. Record or refresh evidence

Open the relevant promise and select Record evidence to add a finding, reference, and explanation. Warehouse receipt and inspection are merchant-recorded facts unless a supported provider supplies independent proof. Provider refresh uses the enabled integration and validates the returned identity and state. Failed, missing, stale, or conflicting evidence remains visible for review. Never mark a milestone fulfilled merely to make a progress indicator look complete.

## 13. Next step and refund risk

The case summary explains the next action and what is missing before a refund. Promise health considers accepted terms, deadlines, completed amounts, and pending obligations. The money summary keeps recorded payment data separate from independently verified refund totals. When history is unavailable, confirmed and outstanding totals stay unavailable instead of showing a false verified zero. A risk label or suggested amount is not permission to submit a payment.

## 14. Advisory AI and investigations

Optional AI tools can suggest promises from support conversations, explain structured case facts, and assist investigation review. Suggestions must be checked against their quoted sources and saved through the normal validated workflow. Investigation approval does not authorize a refund. AI requests require configured provider credentials and policy settings. This recording does not claim a successful paid model request; disabled or unavailable AI remains explicitly unavailable.

## 15. Timeline and evidence export

Evidence timeline shows the recorded sequence of promises, revisions, findings, and financial decisions. Inspect who or what supplied each event and when it was checked. Load older entries where available. Evidence exports preserve supporting records for authorized review. They can contain private merchant source material, so do not publish them as ordinary customer messages. The engineering log is a separate development record, not this runtime case history.

## 16. Buyer receipt and printing

Buyer receipt creates a readable summary of the resolution and its evidence. Review completed, pending, blocked, and outstanding states before sharing it. Use the available print control, then choose a printer or Save as PDF in the browser. A receipt can include merchant-recorded milestones, so its appearance alone is not payment confirmation. The verified Sandbox receipt later in this tour has actual independent provider evidence.

## 17. Private buyer links

The Customer portal tab lets the merchant set a buyer heading, choose whether to expose the order reference, and issue a private case link. Share that link through an approved support channel. Treat it as a credential. Links expire and can be replaced or revoked; a replaced link no longer grants the same access. Private token fields are redacted in this video. No merchant key is given to the buyer.

## 18. Messages and attachments

Merchants and buyers exchange messages in the case conversation. Enter the message, send once, and refresh the other view to retrieve the stored reply. Buyers can attach supported PDF, PNG, or JPEG evidence, subject to the displayed size limit. The merchant can inspect and download those files. Private support-source notes stay separate from public replies. The attachment here is a clearly labelled tutorial document, not a shipment or provider record.

## 19. Order-scoped buyer intake

Invite customer creates a private intake link for a specified order. The buyer chooses an issue type, describes the problem, and submits the request. Resolve saves it and opens the scoped case experience. The customer can then exchange messages and upload evidence. Submission creates a support request, not an accepted remedy or a refund. Emailing the invitation requires the separate configured delivery service; copying a private link does not send an email.

## 20. Buyer account and My cases

My cases is for buyers whose cases are associated with an invited mailbox. If configured, they can request an email sign-in link or use Google with the matching verified address. They then open only their own listed cases. These methods are optional; when unavailable, the private case link remains the access path. There is no buyer password-registration or forgot-password flow, and a buyer session cannot enter the merchant workspace.

## 21. Version-bound remedy offers

In Buyer resolution offers, select the current promise versions, choose an expiry, and publish the available option. The buyer reviews the exact wording and conditions before accepting or declining. Acceptance is stored for those versions. Revised or expired terms need a new valid offer. An accepted refund offer is an additional gate, not an automatic refund instruction. The scenes here show actual local acceptance saved by the application.

## 22. Return eligibility and policy

Item-level returns depend on registered order items and the configured policy. Owners can enable review rules, a return window, inspection requirements, a restocking fee, and responsibility for return shipping. Eligibility is evaluated against the actual selected items and recorded facts. A needs-review result is not approval. Public policy output exposes the relevant buyer terms without revealing internal configuration or provider credentials.

## 23. Request an item return

The buyer selects the items and quantities to return, enters a reason, and submits the request. Resolve stores the request and reserves quantities to prevent overlapping returns beyond the order's available quantity. The merchant reviews it and records approval or rejection through the supported steps. A requested return is not already approved, and requesting one does not initiate shipping or purchase postage.

## 24. Return and replacement milestones

Guided returns and replacements record the actual supported lifecycle in order: review, return shipping information, receipt, inspection, replacement shipment where applicable, and completion. Enter an evidence note for each step. A carrier delivery event is different from a warehouse receipt or inspection result. Resolve records and verifies the available evidence; the physical parcel and any replacement shipment must still be arranged through the merchant's normal fulfillment process.

## 25. Instructions and saved PDF labels

The merchant can save return instructions, an address, and shipping responsibility, then attach an existing PDF label. The buyer opens the private portal and downloads that saved file. Upload and download happen through the application and its database. Resolve does not buy or generate carrier postage. The file used for this recorded workflow is labelled as a tutorial document and is not valid postage.

## 26. Inspection and policy exceptions

When policy requires inspection, the merchant records condition, quantity agreement, and the supporting note before advancing the relevant return step. Authorized exceptions require an explicit explanation; they should not be used simply to bypass missing evidence. Restocking and shipping terms remain visible where applicable. These are merchant review decisions, separate from an independently verified payment or carrier result.

## 27. Registered orders

Orders lists purchases registered by the merchant's application server or Resolve's software development kit. Search a reference, inspect the saved item and payment fields, and open an existing case or create support when needed. An order can exist before a customer raises an issue. App-reported values are compared with provider evidence when available. No search result means no matching registered record, not proof that no purchase occurred.

## 28. Guarded refund decisions

An eligible refund needs the correct capture, amount, currency, seller, current history, accepted agreement, and satisfied conditions. Authorized staff review an exact amount and create a time-limited, state-bound approval. Submission is a separate action, with the state checked again. Pending or uncertain outcomes, changed terms, shared capture balances, or active dispute holds can block another refund. Current execution is PayPal Sandbox only; this recording submits no new payment.

## 29. Verified one-dollar Sandbox result

These recorded screens show the official Sandbox workflow that the owner explicitly authorized earlier. PayPal created the one-dollar order, the buyer privately approved it, and the existing adapter captured it. Resolve then enforced its separate refund approval and execution checks. An independent PayPal read confirmed the full refund as completed. The database contains exactly one refund, the case is fulfilled, and the remaining amount is zero. This is real Sandbox evidence, not production deployment.

## 30. Where is the refund?

The buyer's refund journey distinguishes an agreement, a pending processor result, a provider-reported completed refund, and a buyer-reported receipt. Freshness matters: unavailable evidence must not become a confirmed zero. The verified example shows one dollar confirmed and zero outstanding, with a completed provider result. Posting to the original payment method can take additional time. Resolve does not independently verify the buyer's bank balance or final bank credit.

## 31. Disputes and capture-wide holds

Authorized staff can record dispute state and its source reference. An active dispute or reimbursement overlap can hold the entire capture against another refund, including related cases. Review the current evidence before recording a resolution. The screen here is an explicitly merchant-recorded quality assurance example; no PayPal dispute was submitted. Recording a provider name in a note does not turn that note into independent provider verification.

## 32. Refund tracing references

Refund tracing helps the merchant give a buyer an available reference, such as an actual known tracing identifier from the provider. Authorized finance or owner users record the reference and its source, while private notes remain internal. A trace is not itself proof of bank receipt. This tour shows the entry form without inventing a real tracing number or claiming a bank outcome.

## 33. Reviewed dispute evidence packages

Prepare a dispute evidence package using the relevant reference and reason. Inspect the captured snapshot and its missing-evidence checklist. An authorized reviewer records review before a current package can be exported as JSON. If relevant evidence changes, prepare and review a new snapshot instead of assuming the old package is current. Exporting a package does not submit a dispute response to PayPal.

## 34. Operations dashboard

Operations gives the merchant a workspace-wide view of outcomes, overdue work, complaint categories, evidence gaps, and closure-time samples. Financial totals are recorded ledger values, with shared captures counted once rather than duplicated across cases. Keep that ledger source separate from independent provider proof. The sample count matters when reading average resolution time; a small local workspace is not a production performance benchmark. Open Audit to inspect actor-attributed workspace changes and timestamps. This runtime history is separate from a case timeline and the development engineering log.

## 35. Overdue watchdog and drafts

Missed promises scans the workspace for overdue obligations and prepares alerts and customer-update drafts. Open the relevant case, review its current state, and copy or adapt the draft for your approved communication channel. A scan does not send the draft and does not issue a refund. Periodic scanning needs the operations worker to be deployed and running. The displayed result comes from an actual local scan.

## 36. Helpdesk imports and matching

Support imports can bring in a Zendesk ticket through an enabled connection. Review the imported source and its match to an order or case; if several records are plausible, explicitly select and confirm the correct one. Private source comments remain merchant evidence rather than buyer messages. Missing credentials or permissions produce a failure or unavailable state. This video does not claim an account-backed Zendesk import when that connection is not configured.

## 37. Team roles and invitations

Owners invite staff using a private, single-use invitation and select the appropriate role. Agents work on cases, managers can review refund approvals and dispute packages, finance can submit eligible approved Sandbox refunds, and viewers are read only. Owners manage team access, connections, and keys. Role changes or deactivation revoke sessions. The actual local agent workflow shown here is denied restricted key administration by the backend, even if a control is visible.

## 38. Provider connections

Connections is where an owner configures the supported PayPal Sandbox, Shopify, EasyPost, and Zendesk access. Saved provider secrets are encrypted; blank secret fields can preserve existing values when editing. Use Check account access only after configuring the intended account. A successful account check does not establish ownership of every capture or order. Credentials and provider permissions must be verified separately, and no secret should be placed in frontend public variables or a recording.

## 39. SDK keys and source binding

Settings can issue and revoke scoped integration keys for authorized owners. Copy a new key into the integrating server's secret store and hide it after saving; never put it in browser code. Support keys are bound to an application source and grant the supported order-aftercare operations. A commerce key alone does not gain unrestricted support or financial authority. No generated key is exposed in this video.

## 40. Order-to-support SDK flow

Resolve's first-party Node software development kit is version zero point seven. The merchant's server initializes the client with its API address, private key, and application source, then registers trusted order data. After the store verifies the buyer owns that order, it can open a support issue and obtain safe progress or a private portal link. The backend validates the scoped grant, stores the request, and returns the response to the store. The merchant key stays off the buyer's device.

## 41. Retries, receipts, context, and events

The integration also supports issue lookup, saved support context, return eligibility, return requests, refund journeys, label downloads, and event feeds. Keep a stable request identifier after an uncertain response so recovery does not create a duplicate action. Consumers should deduplicate events, ignore older revisions, and commit their own update and cursor together. A timeout is not proof that a financial action failed. Read the existing outcome before deciding what to retry.

## 42. Backend, APIs, and workers

The application keeps its existing Next.js frontend and FastAPI backend, with SQLite for isolated local work and PostgreSQL for the recommended hosted setup. Same-origin server gateways protect merchant credentials and enforce request boundaries. Separate workers handle financial recovery, follow-up, investigations, and operational scans. Health reports liveness, while readiness probes the database. Provider adapters use HTTPX and official APIs. Optional AI uses the Groq SDK or OpenRouter. PostgreSQL clients, Google token validation, the SMTP mailer, and encrypted connection storage are documented in the SDK implementation guide. These libraries do not prove that an unconfigured external service has been contacted. The reusable OpenAPI contract contains no real credentials.

## 43. Documentation and every guide

Docs provides ten public guides: getting started, merchant workspace, buyer portal, returns and replacements, refunds and disputes, SDK integration, API reliability, connections, running Resolve, and troubleshooting. Search across the guide text, use section anchors, copy code, or print an article. The hub downloads the complete Markdown reference and OpenAPI contract. The accompanying illustrated manual adds page-by-page instructions, roles, common errors, and project-specific SDK implementation details.

## 44. Mobile use and error recovery

On a phone, use the case list and back control to move between the inbox and detail, and scroll the local tab strip where needed. Validate required fields and file sizes before submitting. If a session expires, sign in again. Ask the merchant to replace an expired private link. If a provider or network request fails, read the error and refresh or recover the existing operation; do not repeatedly submit a financial action.

## 45. What has actually been validated

The recorded local audit passed one thousand and five backend checks, with sixty-three opt-in tests skipped. Separate real PostgreSQL runs passed one hundred and ten checks. Browser, SDK, authorization, reconciliation, and controlled failure tests have their own documented scope. A bounded local workload completed three thousand two hundred and twenty requests without HTTP errors. These results do not establish every possible state, production capacity, email delivery, or permissions for an unconfigured external account.

## 46. Deployment scope and conclusion

Resolve brings the support request, agreed remedy, evidence, customer conversation, and next action into one reviewable case. This tour covered the implemented user modules and integration boundaries using genuine application screens. The official one-dollar Sandbox flow is verified, but no public production URL is available yet. Render access, published source, billing approval, and hosted acceptance are still required. Sign out when finished, and use the chapter list, manual, and test reports for a closer review.
