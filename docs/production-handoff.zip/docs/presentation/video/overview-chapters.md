# Project overview chapters (selected from full tour)

Actual local application screenshots and English narration. Official Sandbox evidence is labelled separately. No new payments or successful unconfigured integrations are claimed.

00:00 - Welcome to Resolve
00:29 - Find and prioritize cases
01:01 - Record the agreed remedy
01:36 - Private buyer links
02:04 - Version-bound remedy offers
02:35 - Instructions and saved PDF labels
03:03 - Registered orders
03:32 - Guarded refund decisions
04:08 - Verified one-dollar Sandbox result
04:43 - Reviewed dispute evidence packages
05:10 - Team roles and invitations
05:44 - Order-to-support SDK flow
06:18 - What has actually been validated
06:54 - Deployment scope and conclusion
