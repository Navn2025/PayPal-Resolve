# Video chapters

Actual local application screenshots and English narration. Official Sandbox evidence is labelled separately. No new payments or successful unconfigured integrations are claimed.

00:00 - Welcome to Resolve
00:29 - Home and navigation
01:00 - Create a merchant workspace
01:28 - Sign-in methods and access recovery
01:58 - Sessions and safe account use
02:27 - Find and prioritize cases
02:59 - Review queue and source labels
03:30 - Create a case and link payment
04:01 - Assignment, deadlines, and lifecycle
04:31 - Record the agreed remedy
05:06 - Revisions and dependencies
05:34 - Record or refresh evidence
06:05 - Next step and refund risk
06:36 - Advisory AI and investigations
07:09 - Timeline and evidence export
07:41 - Buyer receipt and printing
08:11 - Private buyer links
08:39 - Messages and attachments
09:11 - Order-scoped buyer intake
09:44 - Buyer account and My cases
10:14 - Version-bound remedy offers
10:45 - Return eligibility and policy
11:16 - Request an item return
11:43 - Return and replacement milestones
12:15 - Instructions and saved PDF labels
12:43 - Inspection and policy exceptions
13:11 - Registered orders
13:40 - Guarded refund decisions
14:17 - Verified one-dollar Sandbox result
14:51 - Where is the refund?
15:24 - Disputes and capture-wide holds
15:54 - Refund tracing references
16:19 - Reviewed dispute evidence packages
16:46 - Operations dashboard
17:27 - Overdue watchdog and drafts
17:54 - Helpdesk imports and matching
18:24 - Team roles and invitations
18:58 - Provider connections
19:32 - SDK keys and source binding
20:00 - Order-to-support SDK flow
20:34 - Retries, receipts, context, and events
21:08 - Backend, APIs, and workers
22:07 - Documentation and every guide
22:47 - Mobile use and error recovery
23:17 - What has actually been validated
23:53 - Deployment scope and conclusion
