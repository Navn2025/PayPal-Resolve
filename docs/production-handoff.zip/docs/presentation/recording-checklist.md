# Recording checklist

## Prepare

- [ ] Complete hosted acceptance and write down the actual URL, release revision, environment and evidence date. If deployment remains blocked, label the entire recording as a local preview.
- [ ] Create a dedicated isolated QA workspace with merchant/finance/agent/viewer accounts as needed. Use a fresh buyer browser profile and non-customer QA data; provider references must be actual Sandbox references.
- [ ] Prepare one ordinary support case, synced item order, current offer, return, existing PDF label, dispute snapshot and a readable receipt. Verify each action before recording.
- [ ] Keep full keys, generated SDK setup, connection credentials, private URL fragments, invitation links, real contacts and customer evidence out of the frame. Never record password entry; pause or cut before signing in.
- [ ] Keep payment writes disabled unless a separate account-backed Sandbox demonstration has been explicitly prepared. Use only real official Sandbox responses; record a blocked state honestly if approval/credentials are missing. Product demo modes are retired.
- [ ] Use 1920x1080 or 1440x900 desktop capture, readable zoom, consistent cursor speed and a clean test browser profile. Include one 390px responsive segment.
- [ ] Turn off desktop notifications and close unrelated applications/tabs. Check microphone level and eliminate background noise.
- [ ] Download the PDF manual and public docs in advance; confirm files open. Recheck screenshot provenance and the test report's limitations.

## Record

- [ ] Follow `video-script.md`; keep total duration between five and eight minutes.
- [ ] Show the actual running address briefly, with no private query or fragment.
- [ ] Show a valid action, one validation/error state, refresh persistence and a role denial where prepared.
- [ ] Explain recorded vs provider-confirmed evidence, approval vs submission, and Sandbox vs live outcomes in plain language.
- [ ] Show search/filtering, versioned promise, evidence timeline, buyer messaging, offer/return workflow, orders, team controls, documentation and receipt.
- [ ] Do not linger on secrets, invitation creation or raw exported private evidence. Use prepared screenshots only when clearly identified as captured evidence.
- [ ] If a live step fails, explain the actual result or re-record after diagnosing it. Do not narrate success over a failed UI.
- [ ] End by signing out of merchant and buyer sessions.

## Review and deliver

- [ ] Watch the entire exported video with sound; check narration, captions, cursor, legibility and scene order.
- [ ] Inspect every frame around sign-in, private links, key setup, connections and exports for exposed credentials/customer information. Replace/redact the affected recording and rotate any exposed credential.
- [ ] Match feature claims to the demonstrated release. Remove unsupported speed, reliability, production or provider-success claims.
- [ ] Export MP4/H.264 at 1080p with clear audio; add captions and a short description listing local/simulated/hosted evidence scope.
- [ ] Verify final video duration, playback, sharing permission and links. Keep an editable recording project and the script with the release artifacts.

CHG-057 delivers actual narrated screenshot walkthroughs with English speech,
captions and chapters; see [video/README.md](video/README.md) and its verification
report. This checklist remains for a future continuous live recording. Unchecked
items are not represented as completed by assembling the screenshot videos.
