# English video walkthroughs

The **24:31 full guide** covers implemented user modules and main actions in **46 chapters**. The **7:32 overview** selects 14 chapters suitable for a project presentation. [Open the offline player](watch.html) with both MP4s in this directory, or open the videos directly. Measured durations and validation are recorded in [verification-report.md](verification-report.md).

## Files

- `resolve-full-walkthrough.mp4`: detailed 1080p feature guide with English narration, burned captions and embedded chapters.
- `resolve-project-overview.mp4`: approximately 7.5-minute selected-feature presentation; the header explicitly identifies it as selected chapters. Chapter numbers refer to the full guide.
- `resolve-walkthrough.en.srt` / `overview-resolve-walkthrough.en.srt`: synchronized English captions.
- `chapters.md` / `overview-chapters.md`: seek times and chapter names.
- `transcript.md` and `narration.json`: editable narration and shot/storyboard definitions.
- `english-voiceover.mp3`: standalone English voice-over.
- `video-manifest.json` / `overview-video-manifest.json`: observed durations, hashes, caption counts and genuine source-image hashes.
- `watch.html` / `poster.png`: offline player with edition selection and seekable chapter navigation.
- `verification-report.md`, `verification.json` and `player-verification.json`: media and browser checks, including their limits.
- `screenshots/`: additional actual UI workflow captures, with source/privacy provenance. Previously verified Sandbox and public-page captures remain in the user-manual screenshot directory.

Generated MP4/MP3 files are kept locally and ignored by Git to avoid committing large regenerable media. They are not hidden or removed; open them at the paths above. The documentation archive includes source/captions/provenance, while videos are delivered separately.

## Scope and privacy

These are narrated editorial walkthroughs assembled from genuine application screenshots with detail pans, not a continuous live screen recording. No application interface was synthesized or illustrated. Native titles, annotations and the explicitly labelled local-results summary are editorial graphics.

The new capture run uses compiled Next.js, real FastAPI and disposable QA records, with external providers disabled. It exercises actual offer acceptance, return requests/review, saved valid PDF upload/download, messages, evidence attachment, intake, staff invitations/denial, SDK support and local audit history. QA records are not shown as provider-confirmed payments. The attachment is a valid tutorial PDF marked **not postage**; no shipment is purchased or initiated.

The financial chapter uses the earlier owner-authorized official USD 1.00 Sandbox result. That order/capture/full refund and independent reads were verified under CHG-056. The video task submits no new order, capture, refund, delivery or paid inference call. Bank credit and hosted production remain unverified. Optional identity, carrier, helpdesk, email and AI integrations are explained within their configured/blocked scope.

Password fields, private invitations/links, generated keys and key-bearing code blocks are explicitly redacted in new screenshot captures. Tokens do not appear in source descriptions or URLs; browser chrome is excluded. All visible QA contact addresses use reserved test domains.

## Free narration and alternatives

Narration is generated locally using the installed **Microsoft Zira Desktop, English (United States)** Windows speech voice. It is synthetic speech, not a cloned voice or a claim of human recording. Native word events supply caption timing. FFmpeg assembles the video; no paid generation credits or external speech service is used.

For a different free voice, import the transcript and captures into [Clipchamp](https://clipchamp.com/en/features/ai-voice-over-generator/). Its [free personal plan supports watermark-free 1080p export](https://support.microsoft.com/en-us/clipchamp/what-are-the-clipchamp-paid-plans-and-how-do-they-work). [OBS Studio](https://obsproject.com/) is free for a future live screen recording; [OpenScreen](https://getopenscreen.com/) offers local recording/editing. Feature/plan details were checked on 11 November 2026; use free assets and review the selected account's capabilities.

## Reproduce

Prerequisites: Windows PowerShell 5.1 (`powershell.exe`), installed English desktop speech voice, Segoe UI fonts, Python/uv, FFmpeg/ffprobe, repository Playwright dependencies and Chromium. Current rendering uses the available NVIDIA H.264 encoder; `--encoder libx264` supports CPU rendering.

From repository root:

```powershell
uv run python scripts/build_video_story.py
powershell.exe -NoProfile -File scripts/synthesize_walkthrough.ps1
uv run --with pillow python scripts/render_walkthrough.py
uv run --with pillow python scripts/build_video_highlights.py
uv run python scripts/verify_walkthrough.py
uv run python scripts/build_video_player.py
node scripts/verify_video_player.mjs
```

Scene audio/intermediates stay under ignored `.local/production-video/`. Source changes invalidate chapter render signatures; complete renders can resume cached chapters. The voice script targets Windows PowerShell, whose desktop speech engine supports the selected installed voice. Native 16 kHz output keeps Windows word events on the audio clock; an initial 24 kHz draft failed timing validation and was replaced. Delivered AAC is resampled to 48 kHz after synchronization. To update only selected voices, pass `-OnlyScenes 34,42`. The overview assembler currently requires the installed NVIDIA encoder; the full renderer also has the CPU option above. Create the player poster with `ffmpeg -ss 3 -i docs/presentation/video/resolve-full-walkthrough.mp4 -frames:v 1 -y docs/presentation/video/poster.png`.

To recapture UI, create the clearly labelled valid tutorial PDF under `.local/production-video/`, then run `node scripts/capture_presentation.mjs`, followed from `frontend` by `npx playwright test --config playwright.presentation.config.ts`. The generator derives captures from the existing isolated platform workflow and refuses unknown source anchors rather than silently recording a different behavior. The first capture attempt had an invalid file-upload payload; the corrected file-path capture passed. No owner runtime or configured hosted database is used.
