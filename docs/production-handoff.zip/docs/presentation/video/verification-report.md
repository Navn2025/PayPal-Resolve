# Video verification

Checked: 2026-11-11T14:11:19.709776+00:00

| Video | Duration | Chapters | Caption cues | Resolution / frame rate | Decode | Loudness | Peak |
|---|---|---:|---:|---|---|---:|---:|
| resolve-full-walkthrough.mp4 | 24:31 | 46 | 389 | 1920 x 1080 / 25 fps | Passed, entire file | -18.1 LUFS | -1.6 dBFS |
| resolve-project-overview.mp4 | 7:32 | 14 | 121 | 1920 x 1080 / 25 fps | Passed, entire file | -18.0 LUFS | -1.8 dBFS |

Both outputs contain H.264 video, AAC narration at 48 kHz, burned English captions, embedded chapter metadata and fast-start metadata. Video/audio durations agree within 0.2 seconds. All caption cues are ordered and within the observed duration; source-image and final-video hashes match. No narration gap longer than six seconds was detected. No configured provider credential, payment or paid generation service was used for video creation.

Programmatic full decode, stream/AV timing, native speech-event captions, loudness/gap checks and source hashes; sampled frames visually reviewed. Not a claim of human listening to every spoken word. UI visuals are screenshots/detail pans, not continuous live screen recording.

The full guide explains implemented modules and main actions. The short version is labelled selected chapters and does not claim exhaustive feature coverage. QA and earlier real Sandbox evidence remain explicitly separate. Additional unconfigured integrations, production deployment, bank credit and every possible UI/error state are not claimed as verified by this video.
