# Actual application screenshots

Captured 11 November 2026 from compiled local Next.js and actual FastAPI storage using Chromium. **These are local screenshots, not deployed production screenshots.** No application UI image was generated or illustrated. Files 40-44 show the actual authorized USD 1 official PayPal Sandbox workflow, independently confirmed completed and refunded. Other captures show manually entered QA records with providers disabled and missing verification labelled unavailable. No provider mock supplied data to this manual capture set. Browser chrome, private links and cookies are excluded.

Filename suffixes show viewport width: 1440 desktop, 1180 laptop, 768 tablet, 390 phone. Full-page height may exceed viewport height. Number 30 is an element capture of the actual dialog. Long PDF images are explicitly captioned if only an upper portion is shown; complete PNGs remain here.

The manifest records origin, source, dimensions, date and SHA-256, without private token fragments or cookies. Hosted captures remain blocked by deployment; do not relabel local images as production.

| Screenshot | Caption | Pixel dimensions |
|---|---|---|
| [01-home-1180.png](01-home-1180.png) | Home | 1180 x 1517 |
| [01-home-1440.png](01-home-1440.png) | Home | 1440 x 1635 |
| [01-home-390.png](01-home-390.png) | Home | 390 x 2221 |
| [01-home-768.png](01-home-768.png) | Home | 768 x 1844 |
| [02-merchant-login-1180.png](02-merchant-login-1180.png) | Merchant login | 1180 x 1000 |
| [02-merchant-login-1440.png](02-merchant-login-1440.png) | Merchant login | 1440 x 1000 |
| [02-merchant-login-390.png](02-merchant-login-390.png) | Merchant login | 390 x 844 |
| [02-merchant-login-768.png](02-merchant-login-768.png) | Merchant login | 768 x 1000 |
| [03-account-1180.png](03-account-1180.png) | Account | 1180 x 1000 |
| [03-account-1440.png](03-account-1440.png) | Account | 1440 x 1000 |
| [03-account-390.png](03-account-390.png) | Account | 390 x 844 |
| [03-account-768.png](03-account-768.png) | Account | 768 x 1000 |
| [04-buyer-entry-1180.png](04-buyer-entry-1180.png) | Buyer entry | 1180 x 1000 |
| [04-buyer-entry-1440.png](04-buyer-entry-1440.png) | Buyer entry | 1440 x 1000 |
| [04-buyer-entry-390.png](04-buyer-entry-390.png) | Buyer entry | 390 x 844 |
| [04-buyer-entry-768.png](04-buyer-entry-768.png) | Buyer entry | 768 x 1000 |
| [05-buyer-account-1180.png](05-buyer-account-1180.png) | Buyer account | 1180 x 1000 |
| [05-buyer-account-1440.png](05-buyer-account-1440.png) | Buyer account | 1440 x 1000 |
| [05-buyer-account-390.png](05-buyer-account-390.png) | Buyer account | 390 x 844 |
| [05-buyer-account-768.png](05-buyer-account-768.png) | Buyer account | 768 x 1000 |
| [07-buyer-case-1180.png](07-buyer-case-1180.png) | Buyer case | 1180 x 1306 |
| [07-buyer-case-1440.png](07-buyer-case-1440.png) | Buyer case | 1440 x 1312 |
| [07-buyer-case-390.png](07-buyer-case-390.png) | Buyer case | 390 x 1339 |
| [07-buyer-case-768.png](07-buyer-case-768.png) | Buyer case | 768 x 1281 |
| [08-docs-1180.png](08-docs-1180.png) | Docs | 1180 x 2160 |
| [08-docs-1440.png](08-docs-1440.png) | Docs | 1440 x 2161 |
| [08-docs-390.png](08-docs-390.png) | Docs | 390 x 2966 |
| [08-docs-768.png](08-docs-768.png) | Docs | 768 x 2737 |
| [09-guide-getting-started-1180.png](09-guide-getting-started-1180.png) | Guide getting started | 1180 x 1767 |
| [09-guide-getting-started-1440.png](09-guide-getting-started-1440.png) | Guide getting started | 1440 x 1870 |
| [09-guide-getting-started-390.png](09-guide-getting-started-390.png) | Guide getting started | 390 x 2616 |
| [09-guide-getting-started-768.png](09-guide-getting-started-768.png) | Guide getting started | 768 x 2245 |
| [10-guide-merchant-workspace-1180.png](10-guide-merchant-workspace-1180.png) | Guide merchant workspace | 1180 x 2249 |
| [10-guide-merchant-workspace-1440.png](10-guide-merchant-workspace-1440.png) | Guide merchant workspace | 1440 x 2318 |
| [10-guide-merchant-workspace-390.png](10-guide-merchant-workspace-390.png) | Guide merchant workspace | 390 x 3103 |
| [10-guide-merchant-workspace-768.png](10-guide-merchant-workspace-768.png) | Guide merchant workspace | 768 x 2838 |
| [11-guide-buyer-portal-1180.png](11-guide-buyer-portal-1180.png) | Guide buyer portal | 1180 x 1895 |
| [11-guide-buyer-portal-1440.png](11-guide-buyer-portal-1440.png) | Guide buyer portal | 1440 x 1914 |
| [11-guide-buyer-portal-390.png](11-guide-buyer-portal-390.png) | Guide buyer portal | 390 x 2641 |
| [11-guide-buyer-portal-768.png](11-guide-buyer-portal-768.png) | Guide buyer portal | 768 x 2276 |
| [12-guide-returns-and-replacements-1180.png](12-guide-returns-and-replacements-1180.png) | Guide returns and replacements | 1180 x 2135 |
| [12-guide-returns-and-replacements-1440.png](12-guide-returns-and-replacements-1440.png) | Guide returns and replacements | 1440 x 2206 |
| [12-guide-returns-and-replacements-390.png](12-guide-returns-and-replacements-390.png) | Guide returns and replacements | 390 x 3037 |
| [12-guide-returns-and-replacements-768.png](12-guide-returns-and-replacements-768.png) | Guide returns and replacements | 768 x 2666 |
| [13-guide-refunds-and-disputes-1180.png](13-guide-refunds-and-disputes-1180.png) | Guide refunds and disputes | 1180 x 2379 |
| [13-guide-refunds-and-disputes-1440.png](13-guide-refunds-and-disputes-1440.png) | Guide refunds and disputes | 1440 x 2431 |
| [13-guide-refunds-and-disputes-390.png](13-guide-refunds-and-disputes-390.png) | Guide refunds and disputes | 390 x 3414 |
| [13-guide-refunds-and-disputes-768.png](13-guide-refunds-and-disputes-768.png) | Guide refunds and disputes | 768 x 3102 |
| [14-guide-sdk-integration-1180.png](14-guide-sdk-integration-1180.png) | Guide sdk integration | 1180 x 3048 |
| [14-guide-sdk-integration-1440.png](14-guide-sdk-integration-1440.png) | Guide sdk integration | 1440 x 3140 |
| [14-guide-sdk-integration-390.png](14-guide-sdk-integration-390.png) | Guide sdk integration | 390 x 3532 |
| [14-guide-sdk-integration-768.png](14-guide-sdk-integration-768.png) | Guide sdk integration | 768 x 3450 |
| [15-guide-api-and-reliability-1180.png](15-guide-api-and-reliability-1180.png) | Guide api and reliability | 1180 x 2657 |
| [15-guide-api-and-reliability-1440.png](15-guide-api-and-reliability-1440.png) | Guide api and reliability | 1440 x 2708 |
| [15-guide-api-and-reliability-390.png](15-guide-api-and-reliability-390.png) | Guide api and reliability | 390 x 3496 |
| [15-guide-api-and-reliability-768.png](15-guide-api-and-reliability-768.png) | Guide api and reliability | 768 x 3232 |
| [16-guide-connections-1180.png](16-guide-connections-1180.png) | Guide connections | 1180 x 2259 |
| [16-guide-connections-1440.png](16-guide-connections-1440.png) | Guide connections | 1440 x 2305 |
| [16-guide-connections-390.png](16-guide-connections-390.png) | Guide connections | 390 x 2900 |
| [16-guide-connections-768.png](16-guide-connections-768.png) | Guide connections | 768 x 2802 |
| [17-guide-running-resolve-1180.png](17-guide-running-resolve-1180.png) | Guide running resolve | 1180 x 2429 |
| [17-guide-running-resolve-1440.png](17-guide-running-resolve-1440.png) | Guide running resolve | 1440 x 2470 |
| [17-guide-running-resolve-390.png](17-guide-running-resolve-390.png) | Guide running resolve | 390 x 3133 |
| [17-guide-running-resolve-768.png](17-guide-running-resolve-768.png) | Guide running resolve | 768 x 2900 |
| [18-guide-troubleshooting-1180.png](18-guide-troubleshooting-1180.png) | Guide troubleshooting | 1180 x 2526 |
| [18-guide-troubleshooting-1440.png](18-guide-troubleshooting-1440.png) | Guide troubleshooting | 1440 x 2648 |
| [18-guide-troubleshooting-390.png](18-guide-troubleshooting-390.png) | Guide troubleshooting | 390 x 3225 |
| [18-guide-troubleshooting-768.png](18-guide-troubleshooting-768.png) | Guide troubleshooting | 768 x 3086 |
| [19-workspace-registration-390.png](19-workspace-registration-390.png) | Workspace registration | 390 x 844 |
| [20-login-error-390.png](20-login-error-390.png) | Login error | 390 x 844 |
| [21-workspace-1180.png](21-workspace-1180.png) | Workspace | 1180 x 1987 |
| [21-workspace-1440.png](21-workspace-1440.png) | Workspace | 1440 x 2027 |
| [21-workspace-390.png](21-workspace-390.png) | Workspace | 390 x 844 |
| [21-workspace-768.png](21-workspace-768.png) | Workspace | 768 x 2048 |
| [22-orders-1180.png](22-orders-1180.png) | Orders | 1180 x 1000 |
| [22-orders-1440.png](22-orders-1440.png) | Orders | 1440 x 1000 |
| [22-orders-390.png](22-orders-390.png) | Orders | 390 x 844 |
| [22-orders-768.png](22-orders-768.png) | Orders | 768 x 1000 |
| [23-settings-1180.png](23-settings-1180.png) | Settings | 1180 x 1000 |
| [23-settings-1440.png](23-settings-1440.png) | Settings | 1440 x 1000 |
| [23-settings-390.png](23-settings-390.png) | Settings | 390 x 958 |
| [23-settings-768.png](23-settings-768.png) | Settings | 768 x 1000 |
| [24-operations-1180.png](24-operations-1180.png) | Operations | 1180 x 1000 |
| [24-operations-1440.png](24-operations-1440.png) | Operations | 1440 x 1000 |
| [24-operations-390.png](24-operations-390.png) | Operations | 390 x 1762 |
| [24-operations-768.png](24-operations-768.png) | Operations | 768 x 1390 |
| [25-operations-audit-390.png](25-operations-audit-390.png) | Operations audit | 390 x 844 |
| [25-operations-connections-390.png](25-operations-connections-390.png) | Operations connections | 390 x 4465 |
| [25-operations-missed-promises-390.png](25-operations-missed-promises-390.png) | Operations missed promises | 390 x 844 |
| [25-operations-support-imports-390.png](25-operations-support-imports-390.png) | Operations support imports | 390 x 888 |
| [25-operations-team-390.png](25-operations-team-390.png) | Operations team | 390 x 1050 |
| [28-case-timeline-1440.png](28-case-timeline-1440.png) | Case timeline | 1440 x 1000 |
| [29-case-receipt-1440.png](29-case-receipt-1440.png) | Case receipt | 1440 x 1077 |
| [30-new-case-form.png](30-new-case-form.png) | New case form | 540 x 354 |
| [40-real-sandbox-case-1440.png](40-real-sandbox-case-1440.png) | Real sandbox case | 1440 x 2204 |
| [41-real-sandbox-orders-1440.png](41-real-sandbox-orders-1440.png) | Real sandbox orders | 1440 x 1000 |
| [42-real-sandbox-buyer-390.png](42-real-sandbox-buyer-390.png) | Real sandbox buyer | 390 x 1632 |
| [43-real-sandbox-receipt-1440.png](43-real-sandbox-receipt-1440.png) | Real sandbox receipt | 1440 x 1052 |
| [44-real-sandbox-timeline-1440.png](44-real-sandbox-timeline-1440.png) | Real sandbox timeline | 1440 x 1000 |
